import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.IOException;
import java.util.ArrayList;

public class AdminMenuUI {
    JPanel AdminPanel;
    private JTabbedPane tabbedPane1;
    private JTextArea ConsoleOutput1;
    private JButton ReportUsers;
    private JButton adminMenuCMDButton;


    public AdminMenuUI(InsuranceCompany insuranceCompany) {
        ArrayList<InsurancePolicy> policies = new ArrayList<>();


        AdminPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentHidden(ComponentEvent e) {
                super.componentHidden(e);
            }
        });
        ReportUsers.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ConsoleOutput1.append(insuranceCompany.printUsersToString());
            }
        });
        adminMenuCMDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Options.AdminMenu(insuranceCompany, policies);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                } catch (CloneNotSupportedException ex) {
                    throw new RuntimeException(ex);
                } catch (PolicyException ex) {
                    throw new RuntimeException(ex);
                } catch (NameException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
}
